import { useState } from "react";
import { addDoc, collection } from "firebase/firestore";
import { db } from "../utils/firebase";

import ResumeForm from "../components/ResumeForm";
import ResumePreview from "../components/ResumePreview";

function Resume() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [github, setGithub] = useState("");
  const [linkedin, setLinkedin] = useState("");
  const [summary, setSummary] = useState("");

  const [education, setEducation] = useState([
    {
      college: "",
      degree: "",
      cgpa: "",
      year: "",
    },
  ]);

  const [experience, setExperience] = useState([
    {
      company: "",
      role: "",
      duration: "",
      description: "",
    },
  ]);

  const [skills, setSkills] = useState([""]);

  const [certifications, setCertifications] = useState([""]);

  const [projects, setProjects] = useState([
    {
      title: "",
      techStack: "",
      description: "",
      github: "",
    },
  ]);

  const saveResume = async () => {
    try {
      await addDoc(collection(db, "resumes"), {
        name,
        email,
        phone,
        github,
        linkedin,
        summary,
        education,
        experience,
        skills,
        certifications,
        projects,
        createdAt: new Date(),
      });

      alert("✅ Resume Saved Successfully!");
    } catch (error) {
      console.error(error);
      alert("❌ Error Saving Resume");
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 p-8">
      <div className="grid lg:grid-cols-2 gap-8">

        <ResumeForm
          name={name}
          setName={setName}

          email={email}
          setEmail={setEmail}

          phone={phone}
          setPhone={setPhone}

          github={github}
          setGithub={setGithub}

          linkedin={linkedin}
          setLinkedin={setLinkedin}

          summary={summary}
          setSummary={setSummary}

          education={education}
          setEducation={setEducation}

          experience={experience}
          setExperience={setExperience}

          skills={skills}
          setSkills={setSkills}

          certifications={certifications}
          setCertifications={setCertifications}

          projects={projects}
          setProjects={setProjects}
        />

        <div>
          <ResumePreview
            name={name}
            email={email}
            phone={phone}
            github={github}
            linkedin={linkedin}
            summary={summary}
            education={education}
            experience={experience}
            skills={skills}
            certifications={certifications}
            projects={projects}
          />

          <button
            onClick={saveResume}
            className="mt-5 w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg font-semibold"
          >
            💾 Save Resume
          </button>
        </div>

      </div>
    </div>
  );
}

export default Resume;
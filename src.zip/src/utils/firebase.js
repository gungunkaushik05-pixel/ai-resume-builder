import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBqB-rcxr8GXNqrtwCFGpxeC1uG-kBi6d4",
  authDomain: "ai-resume-builder-958dc.firebaseapp.com",
  projectId: "ai-resume-builder-958dc",
  storageBucket: "ai-resume-builder-958dc.firebasestorage.app",
  messagingSenderId: "870478030038",
  appId: "1:870478030038:web:18d3754848cb0aecfc5577",
};

const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);
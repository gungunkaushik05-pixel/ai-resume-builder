import { useRef } from "react";
import { useReactToPrint } from "react-to-print";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

function ResumePreview({
  name,
  email,
  phone,
  education,
  experience,
  skills,
  projects,
  photo,
  summary,
}) {
  const resumeRef = useRef();

  const handlePrint = useReactToPrint({
    contentRef: resumeRef,
    documentTitle: "Resume",
  });

  const downloadPDF = async () => {
    const canvas = await html2canvas(resumeRef.current, {
      scale: 2,
    });

    const imgData = canvas.toDataURL("image/png");

    const pdf = new jsPDF("p", "mm", "a4");

    const pdfWidth = 210;
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

    pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
    pdf.save("Resume.pdf");
  };

  return (
    <div>

      {/* Buttons */}

      <div className="flex gap-3 mb-6">
        <button
          onClick={handlePrint}
          className="bg-green-600 hover:bg-green-700 text-white px-5 py-2 rounded-lg"
        >
          🖨 Print
        </button>

        <button
          onClick={downloadPDF}
          className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg"
        >
          📄 Download PDF
        </button>
      </div>

      {/* Resume */}

      <div
        ref={resumeRef}
        className="bg-white w-[794px] min-h-[1123px] mx-auto shadow-2xl rounded-lg p-10"
      >

        {/* Header */}

        <div className="flex justify-between items-start">

          <div>

            <h1 className="text-4xl font-bold uppercase tracking-wide text-gray-800">
              {name || "Your Name"}
            </h1>

            <p className="text-sm text-gray-500 mt-2">
              {email || "your@email.com"}
            </p>

            <p className="text-sm text-gray-500">
              {phone || "+91 9876543210"}
            </p>

          </div>

          <div>

            {photo ? (
              <img
                src={photo}
                alt="Profile"
                className="w-32 h-32 rounded-full border-4 border-blue-600 object-cover"
              />
            ) : (
              <div className="w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center text-gray-500">
                Photo
              </div>
            )}

          </div>

        </div>

        <hr className="my-8" />

        {/* Professional Summary */}

        <h2 className="text-lg font-bold uppercase border-b-2 border-blue-600 pb-1 mb-3">
          Professional Summary
        </h2>

        <p className="text-sm text-gray-700 leading-7 whitespace-pre-line">
          {summary || "Your professional summary will appear here."}
        </p>

        <hr className="my-8" />
                {/* Education */}

        <h2 className="text-lg font-bold uppercase border-b-2 border-blue-600 pb-1 mb-3">
          Education
        </h2>

        {education.map((edu, index) => (
          <div key={index} className="mb-5">

            <h3 className="text-base font-semibold text-gray-800">
              {edu.college || "College Name"}
            </h3>

            <p className="text-sm text-gray-700">
              {edu.degree || "Degree"}
            </p>

            <p className="text-sm text-gray-600">
              CGPA: {edu.cgpa || "--"}
            </p>

            <p className="text-sm text-gray-600">
              {edu.year || "Passing Year"}
            </p>

          </div>
        ))}

        <hr className="my-8" />

        {/* Experience */}

        <h2 className="text-lg font-bold uppercase border-b-2 border-blue-600 pb-1 mb-3">
          Experience
        </h2>

        {experience.map((exp, index) => (
          <div key={index} className="mb-6">

            <h3 className="text-base font-semibold text-gray-800">
              {exp.role || "Job Role"}
            </h3>

            <p className="text-sm text-blue-600 font-medium">
              {exp.company || "Company Name"}
            </p>

            <p className="text-sm text-gray-500 mb-2">
              {exp.duration || "Duration"}
            </p>

            <p className="text-sm text-gray-700 leading-6">
              {exp.description || "Experience description"}
            </p>

          </div>
        ))}

        <hr className="my-8" />
                {/* Projects */}

        <h2 className="text-lg font-bold uppercase border-b-2 border-blue-600 pb-1 mb-3">
          Projects
        </h2>

        {projects.map((project, index) => (
          <div key={index} className="mb-6">

            <h3 className="text-base font-semibold text-gray-800">
              {project.title || "Project Title"}
            </h3>

            <p className="text-sm text-blue-600 font-medium mb-1">
              Tech Stack: {project.techStack || "React, Firebase"}
            </p>

            <p className="text-sm text-gray-700 leading-6 mb-2">
              {project.description || "Project description"}
            </p>

            {project.github && (
              <a
                href={project.github}
                target="_blank"
                rel="noreferrer"
                className="text-sm text-blue-700 underline break-all"
              >
                {project.github}
              </a>
            )}

          </div>
        ))}

        <hr className="my-8" />

        {/* Skills */}

        <h2 className="text-lg font-bold uppercase border-b-2 border-blue-600 pb-1 mb-3">
          Skills
        </h2>

        <div className="flex flex-wrap gap-2">
          {skills.map((skill, index) => (
            <span
              key={index}
              className="bg-gray-200 text-gray-800 px-4 py-1 rounded-full text-sm font-medium"
            >
              {skill || "Skill"}
            </span>
          ))}
        </div>

      </div>
    </div>
  );
}

export default ResumePreview;